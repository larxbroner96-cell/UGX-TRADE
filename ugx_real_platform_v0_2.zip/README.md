# UGX Real Trading Platform V0.2

Production-oriented foundation for a regulated UGX trading platform.

## What is included
- PostgreSQL schema
- Users and KYC status
- UGX wallets
- Double-entry-style ledger entries
- Idempotent payment webhook
- Payments table
- Orders/positions schema
- Audit log
- Sandbox/live-trading feature flag
- Docker Compose

## Start locally
`docker compose up --build`

API:
`http://localhost:8000/docs`

## Important
LIVE_TRADING defaults to false. Do not enable it until the authorized liquidity/execution adapter, risk controls, payment production configuration, reconciliation, security review, and operational approvals are completed.

MTN integration credentials must be supplied through environment variables. Never commit API keys or secrets.
