import os, uuid
from decimal import Decimal
from datetime import datetime, timezone
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, String, Numeric, DateTime, ForeignKey, Boolean, text
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./ugxtrade.db")
LIVE_TRADING = os.getenv("LIVE_TRADING", "false").lower() == "true"

engine = create_engine(DATABASE_URL, pool_pre_ping=True)
Session = sessionmaker(bind=engine)

class Base(DeclarativeBase): pass

def now(): return datetime.now(timezone.utc)

class User(Base):
    __tablename__="users"
    id: Mapped[str]=mapped_column(String(36),primary_key=True)
    phone: Mapped[str]=mapped_column(String(32),unique=True,index=True)
    kyc_status: Mapped[str]=mapped_column(String(20),default="pending")
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class Wallet(Base):
    __tablename__="wallets"
    id: Mapped[str]=mapped_column(String(36),primary_key=True)
    user_id: Mapped[str]=mapped_column(ForeignKey("users.id"),index=True)
    currency: Mapped[str]=mapped_column(String(3),default="UGX")
    available: Mapped[Decimal]=mapped_column(Numeric(20,2),default=0)
    locked: Mapped[Decimal]=mapped_column(Numeric(20,2),default=0)

class LedgerEntry(Base):
    __tablename__="ledger_entries"
    id: Mapped[str]=mapped_column(String(36),primary_key=True)
    wallet_id: Mapped[str]=mapped_column(ForeignKey("wallets.id"),index=True)
    reference: Mapped[str]=mapped_column(String(64),index=True)
    entry_type: Mapped[str]=mapped_column(String(30))
    amount: Mapped[Decimal]=mapped_column(Numeric(20,2))
    direction: Mapped[str]=mapped_column(String(10))
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class Order(Base):
    __tablename__="orders"
    id: Mapped[str]=mapped_column(String(36),primary_key=True)
    user_id: Mapped[str]=mapped_column(ForeignKey("users.id"),index=True)
    pair: Mapped[str]=mapped_column(String(16))
    side: Mapped[str]=mapped_column(String(4))
    units: Mapped[Decimal]=mapped_column(Numeric(20,6))
    price: Mapped[Decimal]=mapped_column(Numeric(20,6))
    status: Mapped[str]=mapped_column(String(20),default="pending")
    idempotency_key: Mapped[str]=mapped_column(String(80),unique=True)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class Position(Base):
    __tablename__="positions"
    id: Mapped[str]=mapped_column(String(36),primary_key=True)
    order_id: Mapped[str]=mapped_column(ForeignKey("orders.id"))
    user_id: Mapped[str]=mapped_column(ForeignKey("users.id"),index=True)
    pair: Mapped[str]=mapped_column(String(16))
    side: Mapped[str]=mapped_column(String(4))
    units: Mapped[Decimal]=mapped_column(Numeric(20,6))
    entry_price: Mapped[Decimal]=mapped_column(Numeric(20,6))
    status: Mapped[str]=mapped_column(String(20),default="open")
    opened_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class Payment(Base):
    __tablename__="payments"
    id: Mapped[str]=mapped_column(String(36),primary_key=True)
    user_id: Mapped[str]=mapped_column(ForeignKey("users.id"),index=True)
    provider: Mapped[str]=mapped_column(String(20))
    external_id: Mapped[str]=mapped_column(String(100),unique=True)
    amount: Mapped[Decimal]=mapped_column(Numeric(20,2))
    currency: Mapped[str]=mapped_column(String(3),default="UGX")
    status: Mapped[str]=mapped_column(String(20),default="pending")
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

class AuditLog(Base):
    __tablename__="audit_logs"
    id: Mapped[str]=mapped_column(String(36),primary_key=True)
    actor: Mapped[str]=mapped_column(String(36))
    action: Mapped[str]=mapped_column(String(50))
    reference: Mapped[str]=mapped_column(String(80))
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True),default=now)

Base.metadata.create_all(engine)

app=FastAPI(title="UGX Real Trading Platform API",version="0.2")

class CreateUser(BaseModel):
    phone: str
class DepositWebhook(BaseModel):
    external_id: str
    user_id: str
    amount: Decimal = Field(gt=0)
    status: str

@app.get("/health")
def health():
    return {"ok":True,"live_trading":LIVE_TRADING,"environment":"sandbox" if not LIVE_TRADING else "production"}

@app.post("/users")
def create_user(body:CreateUser):
    with Session.begin() as db:
        if db.query(User).filter_by(phone=body.phone).first():
            raise HTTPException(409,"User already exists")
        uid=str(uuid.uuid4()); wid=str(uuid.uuid4())
        db.add(User(id=uid,phone=body.phone))
        db.add(Wallet(id=wid,user_id=uid,currency="UGX",available=0,locked=0))
        db.add(AuditLog(id=str(uuid.uuid4()),actor=uid,action="USER_CREATED",reference=uid))
        return {"user_id":uid,"wallet_id":wid,"kyc_status":"pending"}

@app.get("/wallets/{user_id}")
def wallet(user_id:str):
    with Session() as db:
        w=db.query(Wallet).filter_by(user_id=user_id).first()
        if not w: raise HTTPException(404,"Wallet not found")
        return {"currency":w.currency,"available":str(w.available),"locked":str(w.locked)}

@app.post("/payments/webhook")
def payment_webhook(body:DepositWebhook):
    # Idempotent: external_id is unique. Only successful verified callbacks credit funds.
    if body.status.lower() not in ("successful","success","completed"):
        return {"accepted":True,"credited":False}
    with Session.begin() as db:
        existing=db.query(Payment).filter_by(external_id=body.external_id).first()
        if existing: return {"accepted":True,"credited":False,"duplicate":True}
        w=db.query(Wallet).filter_by(user_id=body.user_id,currency="UGX").first()
        if not w: raise HTTPException(404,"Wallet not found")
        pid=str(uuid.uuid4())
        db.add(Payment(id=pid,user_id=body.user_id,provider="momo",external_id=body.external_id,amount=body.amount,status="successful"))
        w.available += body.amount
        db.add(LedgerEntry(id=str(uuid.uuid4()),wallet_id=w.id,reference=body.external_id,entry_type="deposit",amount=body.amount,direction="credit"))
        db.add(AuditLog(id=str(uuid.uuid4()),actor=body.user_id,action="DEPOSIT_CREDITED",reference=body.external_id))
        return {"accepted":True,"credited":True,"amount":str(body.amount)}

@app.post("/orders")
def order(user_id:str,pair:str,side:str,units:Decimal,idempotency_key:str):
    if not LIVE_TRADING:
        raise HTTPException(503,"Trading execution is disabled: sandbox mode")
    raise HTTPException(501,"Connect an approved liquidity/execution adapter before enabling live trading")
